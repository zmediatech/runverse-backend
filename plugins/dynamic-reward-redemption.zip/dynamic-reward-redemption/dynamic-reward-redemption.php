<?php
/*
Plugin Name: Dynamic Reward Redemption
Description: Handles dynamic reward redemption via rewardlogin token and applies discounts on WooCommerce cart.
Version: 1.0
Author: Meer Muneeb Khan
*/

// Add rewrite rule for rewardlogin URL with token and reward
add_action('init', function() {
    add_rewrite_rule('^rewardlogin/?$', 'index.php?dynamic_reward_rewardlogin=1', 'top');
    add_rewrite_tag('%dynamic_reward_rewardlogin%', '1');
});

// Flush rewrite rules on plugin activation/deactivation
register_activation_hook(__FILE__, function() {
    flush_rewrite_rules();
});
register_deactivation_hook(__FILE__, function() {
    flush_rewrite_rules();
});

add_action('template_redirect', function() {
    global $wp_query;

    if (!isset($wp_query->query_vars['dynamic_reward_rewardlogin'])) {
        return;
    }

    $token = isset($_GET['token']) ? sanitize_text_field($_GET['token']) : '';
    $reward = isset($_GET['reward']) ? sanitize_text_field($_GET['reward']) : '';

    if (!$token) {
        wp_die('Missing login token.', 'Reward Login Error', ['response' => 400]);
    }

    // Verify token with your backend API
    $verify_url = 'https://runverse-backend.vercel.app/api/users/verify-token';

    $response = wp_remote_post($verify_url, [
        'body'    => json_encode(['token' => $token]),
        'headers' => ['Content-Type' => 'application/json'],
        'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
        wp_die('Token verification failed: ' . $response->get_error_message(), 'Reward Login Error', ['response' => 500]);
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (empty($body) || empty($body['wooCustomerId'])) {
        wp_die('Invalid or expired token.', 'Reward Login Error', ['response' => 403]);
    }

    $user_id = intval($body['wooCustomerId']);

    if (!$user_id) {
        wp_die('User not found.', 'Reward Login Error', ['response' => 404]);
    }

    // Log the user in programmatically
    wp_set_auth_cookie($user_id);
    wp_set_current_user($user_id);

    // Save reward info in PHP session to use on cart pages
    if (!session_id()) {
        session_start();
    }
    $_SESSION['dynamic_reward'] = $reward;

    // Redirect to homepage or cart page
    wp_redirect(wc_get_cart_url());
    exit;
});

add_action('woocommerce_cart_calculate_fees', function($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    if (!session_id()) {
        session_start();
    }

    if (empty($_SESSION['dynamic_reward'])) {
        return;
    }

    $reward = $_SESSION['dynamic_reward'];
    // Decode reward info (you can JSON encode the reward on the URL)
    $reward_data = json_decode(stripslashes($reward), true);

    if (!$reward_data || empty($reward_data['type'])) {
        return;
    }

    $discount_total = 0;

    switch ($reward_data['type']) {
        case 'free_item':
            // Check if product is in cart and discount one item to zero
            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                if ($cart_item['product_id'] == $reward_data['productId']) {
                    $price = $cart_item['data']->get_price();
                    // Discount price of one item once
                    $discount_total = $price;
                    break;
                }
            }
            break;

        case 'product_discount':
            // Apply discount to matching product only once
            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                if ($cart_item['product_id'] == $reward_data['productId']) {
                    $price = $cart_item['data']->get_price();
                    $discount_total = ($reward_data['discount'] / 100) * $price;
                    break;
                }
            }
            break;

        case 'vendor_discount':
            // Vendor discount applies to all vendor products in cart
            foreach ($cart->get_cart() as $cart_item_key => $cart_item) {
                $vendor_id = get_post_field('post_author', $cart_item['product_id']);
                if ($vendor_id == $reward_data['vendorId']) {
                    $price = $cart_item['data']->get_price() * $cart_item['quantity'];
                    $discount_total += ($reward_data['discount'] / 100) * $price;
                }
            }
            break;

        case 'site_wide':
            // Site-wide discount on full cart total
            $cart_total = $cart->get_subtotal();
            $discount_total = ($reward_data['discount'] / 100) * $cart_total;
            break;
    }

    if ($discount_total > 0) {
        $cart->add_fee(__('Reward Discount', 'dynamic-reward-redemption'), -$discount_total);
    }
});

add_action('woocommerce_before_cart', 'show_dynamic_reward_notice');
add_action('woocommerce_before_checkout_form', 'show_dynamic_reward_notice');

function show_dynamic_reward_notice() {
    if (!session_id()) {
        session_start();
    }
    if (isset($_SESSION['dynamic_reward'])) {
        wc_print_notice(__('Please redeem your reward in one go. Do not close the browser or leave without checking out, or your rewards may be lost.'), 'notice');
    }
}

add_action('woocommerce_thankyou', function($order_id) {
    if (!session_id()) {
        session_start();
    }
    if (isset($_SESSION['dynamic_reward'])) {
        unset($_SESSION['dynamic_reward']);
    }
});
